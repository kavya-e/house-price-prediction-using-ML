<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>House Price Predictor!</title>
  </head>

  <style>
	body
	{

		margin:0;
		padding:0;
		background:url("house.png");
		background-size:cover;
		font-family: sans-serif;
	}

	.card
	{
		position:absolute;
		top:50%;
		left:50%;
		transform: translate(-50%, -50%);
		width:350px;
		height:420px;
		padding:80px 40px;
		box-sizing: border-box;
		background:rgba(0,0,0,0.5) ;

	}

  h1
	{
		margin:0;
		padding:0 0 20px;
		color:#1E90FF;
		text-align:center;
	}

  .placeholder
	{
		color:rgba(255,255,255,0.5);
	}



</style>

  <body class="bg-dark">
    <div class="container">
      <div class="row">
        <div class="card" style="width: 100%; height: 100%;margin-top: 50px">

          <div class="card-body">
            <div class="card-header" style="text-align:center">
              <h1>welcome to house price predictor</h1>
            </div>

            <form method="post" accept-charset="utf-8">
              <div class="row">

                <div class="col-md-6 form-group" style="text-align: center;color: #fff">
                  <label><b>Select the Location:</b></label>
                  <select class="selectpicker form-control" id="location" name="location" required="1" style="	background:rgba(0,0,0,0) ">

                  </select>
                </div>
                <div class="col-md-6 form-group" style="text-align: center;color: #fff;">
                  <label><b>Enter BHK:</b></label>
                  <input type="text" class="form-control" id="bhk" name="bhk" placeholder="Enter BHK" style="	background:rgba(0,0,0,0);color: #fff">
                </div>
                <div class="col-md-6 form-group" style="text-align: center;color: #fff;">
                  <label><b>Enter no. of bathroomsK:</b></label>
                  <input type="text" class="form-control" id="bath" name="bath" placeholder="Enter no. of bathrooms " style="	background:rgba(0,0,0,0);color: #fff ">
                </div>
                <div class="col-md-6 form-group" style="text-align: center;color: #fff;">
                  <label><b>Enter square feet:</b></label>
                  <input type="text" class="form-control" id="total_sqft" name="total_sqft" placeholder="Enter square feet" style="	background:rgba(0,0,0,0);color: #fff">
                </div>

                <div class="col-md-12 form-group">
                  <button class="btn btn-primary form-control" oneclick="send_data()">Predict price</button>
                </div>

            </div>
            </form>
            <br>

            <div class="col-md-12" style="text-align: center">
                <h1><span id="prediction"></span></h1>
            </div>
              <a href="logout.php"><font size="80px"><p style="text-align:center">Logout</a>

          </div>
        </div>
      </div>
    </div>




    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>



  </body>
</html>
