import pandas as pd
from flask import Flask, render_template,request
import pickle
import numpy as np
app=Flask(__name__,template_folder='template')
#app=Flask(__name__,template_folder='template',static_url_path='/static/', static_folder='/static/')
data=pd.read_csv('train.csv')
pipe=pickle.load(open("LinearModel.pkl",'rb'))
@app.route('/')
def index():
    Neighborhoods= sorted(data['Neighborhood'].unique())
    MSZonings=["C (all)","FV","RH","RL","RM"]
    Util=["AllPub","NoSeWa"]
    Conditions=["Artery","Feedr","Norm","RRNn","RRAn","PosN","PosA","RRNe","RRAe"]
    types=["1Fam","2FmCon","Duplex","TwnhsE","Twnhs"]
    styles=["1Story","1.5Fin","1.5Unf","2Story","2.5Fin","2.5Unf","SFoyer","SLvl"]
    Qualities=["10","9","8","7","6","5","4","3","2","1"]
    Foundations=["BrkTil","CBlock","PConc","Slab","Stone","Wood"]
    GarageTypes=["2Types","Attchd","Basment","BuiltIn","CarPort","Detchd"]

    return render_template('final.html',Neighborhoods=Neighborhoods,MSZonings=MSZonings,Util=Util,Conditions=Conditions,types=types,styles=styles,Qualities=Qualities,Foundations=Foundations,GarageTypes=GarageTypes)

@app.route('/predict',methods=['POST'])
def predict():

    MSZoning=request.form.get('MSZoning')
    Utilities=request.form.get('Utilities')
    Neighborhood=request.form.get('Neighborhood')

    Condition1=request.form.get('Condition1')
    BldgType=request.form.get('BldgType')
    HouseStyle=request.form.get('HouseStyle')
    OverallQual=request.form.get('OverallQual')
    Foundation=request.form.get('Foundation')

    GrLivArea=request.form.get('GrLivArea')
    TotRmsAbvGrd=request.form.get('TotRmsAbvGrd')
    GarageType=request.form.get('GarageType')
    GarageArea=request.form.get('GarageArea')
    FullBath=request.form.get('FullBath')
    HalfBath=request.form.get('HalfBath')
    BedroomAbvGr=request.form.get('BedroomAbvGr')

    Age=request.form.get('Age')


    #print(location,bhk,bath,sqft)
    #input=pd.DataFrame([[location, sqft, bath, bhk]],columns=['location','total_sqft','bath','bhk'])


    input=pd.DataFrame([[MSZoning,Utilities,Neighborhood,Condition1,BldgType,HouseStyle,OverallQual,Foundation,GrLivArea,TotRmsAbvGrd,GarageType,GarageArea,FullBath,HalfBath,BedroomAbvGr,Age]],columns=['MSZoning','Utilities','Neighborhood','Condition1','BldgType','HouseStyle','OverallQual','Foundation','GrLivArea','TotRmsAbvGrd','GarageType','GarageArea','FullBath','HalfBath','BedroomAbvGr','Age'])
    prediction = pipe.predict(input)[0]*1e5
    return str(np.round(prediction,2))
if __name__== "__main__":
    app.run(debug=True,port=5001)
